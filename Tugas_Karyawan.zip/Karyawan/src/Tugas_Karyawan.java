import java.io.PrintStream;
import java.util.Scanner;

public class Tugas_Karyawan {
    public static int Jam_Kerja_Karyawan;
    public static int Jam_Lembur_Karyawan;
    public static double hitungJam_lembur_Karyawan;
    public static double gaji;
    public static double gajiPokok;
    public static double hitGajipokok;
    public static double potongan;
    public static double tunjangan;
    public static double potTunjangan;

    public Tugas_Karyawan() {
    }
    public static int getJamLembur() {
        return Jam_Lembur_Karyawan = Jam_Kerja_Karyawan - 173;
    }
    public static double getHitJamlembur() { return (double)(getJamLembur() * 20000); }
    public static double getPotongan() { potongan = 50000.0; return 50000.0; }
    public static double getGajiPokok() { return gajiPokok = gaji + getHitJamlembur(); }
    public static double getHitGajipokok() { return getGajiPokok() - getPotongan(); }
    public static double getPotTunjangan() { return potTunjangan = tunjangan - potongan; }
    public static void main(String[] args) {
        Scanner topo = new Scanner(System.in);
        System.out.print("Input Jam Kerja Karyawan : ");
        Jam_Kerja_Karyawan = topo.nextInt();
        PrintStream var10000;
        double var10001;
        if (Jam_Kerja_Karyawan > 173) {
            System.out.println("Jam Lembur Karyawan : " + getJamLembur());
            System.out.println("Gaji lembur : Rp." + getHitJamlembur());
            System.out.print("masukkan gaji : Rp.");
            gaji = topo.nextDouble();
            System.out.println("Gaji pokok : Rp." + getHitGajipokok());
            System.out.print("Masukkan Tunjangan : Rp.");
            tunjangan = topo.nextDouble();
            System.out.println("Tunjangan : Rp" + getPotTunjangan());
            System.out.println("");
            System.out.println("Golongan  Gaji Pokok     Tunjangan");
            var10000 = System.out;
            var10001 = getHitGajipokok();
            var10000.println("1         Rp." + var10001 + "   Rp." + getPotTunjangan());
        } else {
            System.out.println("jam lembur : " + getJamLembur());
            System.out.println("Gaji lembur : Rp." + getHitJamlembur());
            System.out.print("masukkan gaji : Rp.");
            gaji = topo.nextDouble();
            System.out.println("Gaji pokok : Rp." + getHitGajipokok());
            System.out.print("Masukkan Tunjangan : Rp.");
            tunjangan = topo.nextDouble();
            System.out.println("Tunjangan : Rp" + getPotTunjangan());
            System.out.println("");
            System.out.println("Golongan  Gaji Pokok     Tunjangan");
            var10000 = System.out;
            var10001 = getHitGajipokok();
            var10000.println("2         Rp." + var10001 + "   Rp." + getPotTunjangan());
        }
    }
}
